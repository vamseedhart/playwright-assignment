// @ts-check
const { test, expect } = require("@playwright/test");

test("site loads properly", async ({ page }) => {
  await page.goto("https://www.flipkart.com");

  await expect(page).toHaveTitle(
    "Online Shopping Site for Mobiles, Electronics, Furniture, Grocery, Lifestyle, Books & More. Best Offers!"
  );
});

test("Search and Add to Cart:", async ({ page }) => {
  await page.goto("https://www.flipkart.com");

  // Search for a laptop
  await page.fill('input[name="q"]', "laptop");
  await page.press('input[name="q"]', "Enter");

  // Click on the first search result
  await page.click("div._4rR01T");

  const [newPage] = await Promise.all([
    page.waitForEvent("popup"),
    page.click("a._1fQZEK"),
  ]);

  await newPage.bringToFront();

  // Add to cart
  await newPage.click("button._2KpZ6l._2U9uOA._3v1-ww");
});

test("test added product in cart", async ({ page }) => {
  // need to complete the above test first
  await page.goto("https://www.flipkart.com");

  // Search for a laptop
  await page.fill('input[name="q"]', "laptop");
  await page.press('input[name="q"]', "Enter");

  // Click on the first search result
  await page.click("div._4rR01T");

  const [newPage] = await Promise.all([
    page.waitForEvent("popup"),
    page.click("a._1fQZEK"),
  ]);

  await newPage.bringToFront();

  // Add to cart
  await newPage.click("button._2KpZ6l._2U9uOA._3v1-ww");

  // Go to cart
  await page.click("a._3ko_Ud");

  // Check if the product is added to cart

  await expect(
    page.getByRole("link", {
      name: "HP 15s Ryzen 3 Dual Core 3250U - (8 GB/1 TB HDD/Windows 10 Home) 15s-GR0012AU Thin and Light Laptop",
    })
  ).toBeVisible();

  // Remove the product from cart

  const [cartPage] = await Promise.all([
    page.waitForEvent("popup"),
    page.click("button._3dsJAO"),
  ]);

  await cartPage.bringToFront();

  await cartPage.click("button._2KpZ6l._2U9uOA._3v1-ww");

  // Check if the product is removed from cart

  await expect(
    page.getByRole("link", {
      name: "HP 15s Ryzen 3 Dual Core 3250U - (8 GB/1 TB HDD/Windows 10 Home) 15s-GR0012AU Thin and Light Laptop",
    })
  ).not.toBeVisible();
});

test("check the complete flow once", async ({ page }) => {
  // Navigate to the Flipkart website
  await page.goto("https://www.flipkart.com");

  // Search for a laptop
  await page.type('input[type="text"]', "laptop");
  await page.press('input[type="text"]', "Enter");

  // Wait for search results and click on the first product
  await page.waitForSelector("div._4rR01T");
  await page.click("div._4rR01T");

  // Wait for the new page to open
  const [newPage] = await Promise.all([
    page.waitForEvent("popup"),
    page.click("div._4rR01T"),
  ]);

  // Switch to the new page
  await newPage.bringToFront();

  // Add the laptop to the cart
  await newPage.waitForSelector("button._2KpZ6l._2U9uOA._3v1-ww");
  await newPage.click("button._2KpZ6l._2U9uOA._3v1-ww");

  // Proceed to checkout
  await newPage.waitForSelector("button._2KpZ6l._2ObP1N._3AWRsL");
  await newPage.click("button._2KpZ6l._2ObP1N._3AWRsL");

  // User Authentication
  await newPage.waitForSelector('input[name="username"]');
  await newPage.type('input[name="username"]', "your_username");
  await newPage.type('input[name="password"]', "your_password");
  await newPage.click('button[type="submit"]');

  // Wait for navigation to checkout page
  await newPage.waitForNavigation();

  // Verify that the user is successfully logged in
  const loggedInUserName = await newPage.textContent(".user-name");
  if (!loggedInUserName.includes("Your Name")) {
    throw new Error("Failed to log in");
  }

  // Shipping Information
  await newPage.type('input[name="address"]', "123 Main St");
  await newPage.type('input[name="city"]', "New York");
  await newPage.type('input[name="state"]', "NY");
  await newPage.type('input[name="zip"]', "10001");

  // Proceed to the next step
  await newPage.click("button#continue-to-payment");

  // Payment Information
  await newPage.selectOption('select[name="payment-method"]', "credit-card");

  // Review Order
  const orderSummary = await newPage.textContent("div.order-summary");
  if (!orderSummary.includes("laptop")) {
    throw new Error("Incorrect item in the order summary");
  }
});
